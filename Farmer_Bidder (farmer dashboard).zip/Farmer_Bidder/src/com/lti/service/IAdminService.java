package com.lti.service;

import java.util.List;

import com.lti.model.PotentialCrop;

public interface IAdminService {
	public List<PotentialCrop> listAllCrops();

}
