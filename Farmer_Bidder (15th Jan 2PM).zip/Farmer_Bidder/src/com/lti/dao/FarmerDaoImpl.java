package com.lti.dao;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import com.lti.model.Farmer;
import com.lti.model.Login;
import com.lti.model.PotentialCrop;
@Repository
public class FarmerDaoImpl implements IFarmerDao{
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	private static final Logger logger = 			
			LoggerFactory.getLogger(FarmerDaoImpl.class);
	public void addFarmers(Farmer farmer) {
		Session session = this.sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(farmer);
		logger.info("Farmer details saved successfully as: "+farmer);
		tx.commit();
		session.close();
		
	}
	@Override
	public boolean loginFarmers(Login login) {
		Session session = this.sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		String email=login.getEmail();
		String password=login.getPassword();
		String query="from Login l where l.email=:email and l.password=:password";
		Query q=session.createQuery(query);
		q.setString("email", email);
		q.setString("password",password);
		List<Login> farmerList=q.list();
		tx.commit();
/*		String query1="select farmerId from Farmer f,Login l where f.loginId=l.loginId and l.email=:email";
*/		
		session.close();
		if(farmerList.size()==0)
		
		
		return false;
		else
			return true;
		
	}

	@Override
	public void addCrops(PotentialCrop potentialcrop) {
		Session session = this.sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(potentialcrop);
		logger.info("Crop details saved successfully as: "+potentialcrop);
		tx.commit();
		session.close();
	}
	

}
